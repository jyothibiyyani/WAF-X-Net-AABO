# Video-Level Split Files

This folder contains exact video-level split CSV files used for the WAF-X-Net-AABO experiments.

The datasets themselves are not included.

## Important

The CSV files contain generic relative video-folder paths only.
They do not contain absolute Kaggle or local system paths.

Examples:

```text
celeb_df_V2_real_frames/id0_0000
celeb_df_V2_fake_frames/id0_id1_0000
Original_sequences/000
Face2Face/000_003
```

These are video-folder paths, not frame paths.

## Files

```text
celebdf_train_val_split.csv
celebdf_heldout_100real_100fake.csv
ffpp_face2face_subset_500real_500fake.csv
ffpp_face2face_5seed_splits/seed_7_split.csv
ffpp_face2face_5seed_splits/seed_42_split.csv
ffpp_face2face_5seed_splits/seed_123_split.csv
ffpp_face2face_5seed_splits/seed_2024_split.csv
ffpp_face2face_5seed_splits/seed_2025_split.csv
split_generation_metadata.json
```

## CSV Columns

```text
dataset,video_id,relative_path,label,split,seed
```

- label 0 = real
- label 1 = fake
- split = train, validation, heldout, selected_subset, finetune, or evaluation

All splits are performed at the video level before frame sampling.
